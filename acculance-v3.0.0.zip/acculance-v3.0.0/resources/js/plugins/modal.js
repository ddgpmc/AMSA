import Vue from 'vue'
import vmodal from 'vue-js-modal'
Vue.use(vmodal)